/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HeDieuHanh;

public class HDH {
    public static void main(String[] args) {
        Luong1 luong1 = new Luong1();
        Luong2 luong2 = new Luong2();
        Luong3 luong3 = new Luong3();
        luong1.run();
        luong2.run();
        luong3.run();
    }
}
