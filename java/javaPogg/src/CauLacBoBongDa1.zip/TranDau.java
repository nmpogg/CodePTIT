
public class TranDau {
    private String maTD;
    private int soCDV;
    private CLB clb;

    public TranDau(String maTD, int soCDV, CLB clb) {
        this.maTD = maTD;
        this.soCDV = soCDV;
        this.clb = clb;
    }
    public int getDoanhThu(){
        return clb.getGiaVe() * this.soCDV;
    }
    @Override
    public String toString(){
        return this.maTD + " " + clb.getTenCLB() + " " + this.getDoanhThu();
    }
}
