import java.util.*;

public class DanhSachThucTap1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        ArrayList<SinhVienTT> ds = new ArrayList<>();
        for(int i = 1; i <= n; i++){
            SinhVienTT x = new SinhVienTT(i, sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            ds.add(x);
        }
        Collections.sort(ds);
        int q = sc.nextInt();
        sc.nextLine();
        while(q-- > 0){
            String s = sc.nextLine();
            for(SinhVienTT x : ds){
                if(x.getDN().equals(s)) System.out.println(x);
            }
        }
    }
}
