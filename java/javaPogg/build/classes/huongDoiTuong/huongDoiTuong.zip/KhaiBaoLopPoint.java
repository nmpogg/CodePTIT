
package huongDoiTuong;

import java.util.*;

public class KhaiBaoLopPoint {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t-- > 0){
            Point a = new Point(sc.nextDouble(), sc.nextDouble());
            Point b = new Point(sc.nextDouble(), sc.nextDouble());
            System.out.printf("%.4f", Point.distance(a, b));
            System.out.println("");
        }
    }
}
